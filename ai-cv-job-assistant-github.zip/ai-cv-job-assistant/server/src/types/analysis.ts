import { z } from "zod";
export const interviewQuestionSchema=z.object({question:z.string().min(1),reason:z.string().min(1)});
export const analysisSchema=z.object({matchScore:z.number().int().min(0).max(100),summary:z.string().min(1),strengths:z.array(z.string()).max(8),missingKeywords:z.array(z.string()).max(12),improvements:z.array(z.string()).max(10),tailoredSummary:z.string().min(1),interviewQuestions:z.array(interviewQuestionSchema).max(8)});
export type Analysis=z.infer<typeof analysisSchema>;
