# CareerLens — AI CV & Job Application Assistant

A practical full-stack TypeScript application that accepts a PDF/DOCX CV and a job description, extracts the CV text, compares it against the role, and returns structured application advice.

## Features
- React + TypeScript responsive interface
- Express + TypeScript backend API
- PDF and DOCX text extraction
- Multipart upload validation and 5 MB limit
- Structured AI result validation with Zod
- Demo AI provider that works without credentials
- Optional OpenAI Responses API provider
- Match score, strengths, missing keywords, improvements, tailored summary and interview questions
- CV files are processed in memory and not persisted by this demo

## Run
Requirements: Node.js 20+

```bash
npm install
npm run install:all
npm run dev
```

Frontend: http://localhost:5173
API: http://localhost:4000

## Real AI mode
Copy `.env.example` to `.env` in the server directory (or export the variables):

```env
AI_PROVIDER=openai
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4.1-mini
```

Without a key, use `AI_PROVIDER=demo`. This makes the repository easy to clone and test.

## API
`GET /api/health`

`POST /api/analyze` multipart form fields:
- `resume`: PDF/DOCX
- `jobDescription`: at least 50 characters

## Architecture
The frontend never receives an AI key. The server owns document parsing and AI calls. The AI provider is an interface, allowing the deterministic demo provider to be swapped for the live provider without changing the UI.

## Production hardening
For production I would add authentication, antivirus scanning, content/MIME inspection, rate limiting, encrypted storage where retention is required, consent/retention controls, background processing, observability and provider usage limits.

## Portfolio talking points
This demonstrates full-stack TypeScript, file handling, document parsing, API validation, AI integration, structured output, responsive UX, error handling and separation of concerns.

MIT License
